﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using lyw.blueunion.sms.stores.Utilities;
using lyw.blueunion.sms.Dal;
namespace lyw.blueunion.sms.Bll
{
   public class TokenBll
    {
        TokenDal tokdal = new TokenDal();
        public bool validateAccount(string staffId, string staffSecret)
        {
            bool boolflag = tokdal.validateAccount(staffId, staffSecret);
            return boolflag;
        }
    }
}
