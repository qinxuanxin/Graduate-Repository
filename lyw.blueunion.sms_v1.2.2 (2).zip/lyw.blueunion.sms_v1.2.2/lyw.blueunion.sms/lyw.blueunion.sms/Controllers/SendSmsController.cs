﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using lyw.blueunion.sms.Utilities;
using lyw.blueunion.sms.Models;
using Newtonsoft.Json;

namespace lyw.blueunion.sms.Controllers
{
   
    public class SendSmsController : ApiController
    {
        public string getvalue()
        {
            return "hello word";
        }

        #region 发送验证码
        /// <summary>
        /// 获取验证码
        /// </summary>
        /// <param name="mobile"></param>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage GetValidateCode(string mobile)
        {
            ResultValidateMsg resultMsg = null;
            if (string.IsNullOrEmpty(mobile))
            {
                resultMsg = new ResultValidateMsg();
                resultMsg.StatusCode = "isp.phonenum_is_null";
                resultMsg.Info = "手机号码为空";
                resultMsg.BizId = "";
                resultMsg.ValidataCode = "";
                return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));
            }
            resultMsg = new ResultValidateMsg();
            resultMsg = SmsHelper.VerificationCode(mobile);
            return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));

        }
        /// <summary>
        /// 获取验证码
        /// </summary>
        /// <param name="vapostpar"></param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage GetValidateCode(ValidataPostParam vapostpar)
        {
            ResultValidateMsg resultMsg = null;
            if (string.IsNullOrEmpty(vapostpar.mobile))
            {
                resultMsg = new ResultValidateMsg();
                resultMsg.StatusCode = "isp.phonenum_is_null";
                resultMsg.Info = "手机号码为空";
                resultMsg.BizId = "";
                resultMsg.ValidataCode = "";
                return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));
            }
            resultMsg = new ResultValidateMsg();
            resultMsg = SmsHelper.VerificationCode(vapostpar.mobile);
            return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));

        }
        /// <summary>
        /// 灵活发送短信
        /// </summary>
        /// <param name="validatacodepara"></param>
        /// <returns></returns>
        public HttpResponseMessage FlexGetValidateCode(ValidataCodeParameter validatacodepara)
        {
            ResultValidateMsg resultMsg = null;
            if (string.IsNullOrEmpty(validatacodepara.Mobile) || string.IsNullOrEmpty(validatacodepara.AccessKeyId) || string.IsNullOrEmpty(validatacodepara.AccessKeySecret) || string.IsNullOrEmpty(validatacodepara.SignName) || string.IsNullOrEmpty(validatacodepara.TemplateCode) || string.IsNullOrEmpty(validatacodepara.TemplateParam))
            {
                resultMsg = new ResultValidateMsg();
                resultMsg.StatusCode = "isp.parameter_is_not_enough";
                resultMsg.Info = "参数不足";
                resultMsg.BizId = "";
                resultMsg.ValidataCode = "";
                return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));
            }
            resultMsg = new ResultValidateMsg();
            resultMsg = SmsHelper.FlexVerificationCode(validatacodepara);
            return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));

        }
        #endregion  

    }
}
