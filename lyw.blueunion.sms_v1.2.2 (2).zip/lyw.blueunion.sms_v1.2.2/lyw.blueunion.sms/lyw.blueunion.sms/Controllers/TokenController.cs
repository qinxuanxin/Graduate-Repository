﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using lyw.blueunion.sms.Utilities;
using lyw.blueunion.sms.Models;
using System.Web;
using Newtonsoft.Json;
using lyw.blueunion.sms.IEnum;
using lyw.blueunion.sms.Bll;

namespace lyw.blueunion.sms.Controllers
{
    public class TokenController : ApiController
    {

        TokenBll tobll = new TokenBll();
        /// <summary>
        /// 根据用户名获取token
        /// </summary>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public HttpResponseMessage GetToken(string staffId, string staffSecret)
        {
            ResultTokenMsg resultMsg = null;

            //判断参数是否合法
            if (string.IsNullOrEmpty(staffId) || string.IsNullOrEmpty(staffSecret))
            {
                resultMsg = new ResultTokenMsg();
                resultMsg.StatusCode = (int)StatusCodeEnum.ParameterError;
                resultMsg.Info = EnumExtension.GetDescription(StatusCodeEnum.ParameterError);
                resultMsg.Data = "";
                return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));
            }
          //  判断账号信息是否正确
            if (!(tobll.validateAccount(staffId, staffSecret)))
            {
                resultMsg = new ResultTokenMsg();
                resultMsg.StatusCode = (int)StatusCodeEnum.AccountError;
                resultMsg.Info = EnumExtension.GetDescription(StatusCodeEnum.AccountError);
                resultMsg.Data = "";
                return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));
            }

            //插入缓存
            Token token = (Token)HttpRuntime.Cache.Get(staffId.ToString());
            if (HttpRuntime.Cache.Get(staffId.ToString()) == null)
            {
                token = new Token();
                token.StaffId = staffId;
                token.SignToken = Guid.NewGuid();
                token.ExpireTime = DateTime.Now.AddMinutes(5);
                HttpRuntime.Cache.Insert(token.StaffId.ToString(), token, null, token.ExpireTime, TimeSpan.Zero);
            }

            //返回token信息
            resultMsg = new ResultTokenMsg();
            resultMsg.StatusCode = (int)StatusCodeEnum.Success;
            resultMsg.Info = EnumExtension.GetDescription(StatusCodeEnum.Success);
            resultMsg.Data = token;

            return HttpResponseExtension.toJson(JsonConvert.SerializeObject(resultMsg));
        }

    }
}
