﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace lyw.blueunion.sms.Models
{
    public class ValidataPostParam
    {
        public int Id { get; set; }
        public string mobile { get; set; }

        public double name { get; set; }
        public int time { get; set; }
    }
}