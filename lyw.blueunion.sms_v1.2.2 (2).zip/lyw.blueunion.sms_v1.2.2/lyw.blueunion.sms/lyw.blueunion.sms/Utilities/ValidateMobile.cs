﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using lyw.blueunion.sms.IEnum;

namespace lyw.blueunion.sms.Utilities
{
    public class ValidateMobile
    {
        /// <summary>
        /// 验证手机号
        /// </summary>
        /// <param name="mobile"></param>
        /// <returns></returns>
        public static bool Validate(string mobile)
        {
           
            if (IsHandset(mobile))
            {

                return true;
              
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 验证手机号码是否合法
        /// </summary>
        /// <param name="str_handset"></param>
        /// <returns></returns>
        public static bool IsHandset(string str_handset)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(str_handset, @"^1[3|4|5|7|8][0-9]\d{8}$");
        }
     
    }
}