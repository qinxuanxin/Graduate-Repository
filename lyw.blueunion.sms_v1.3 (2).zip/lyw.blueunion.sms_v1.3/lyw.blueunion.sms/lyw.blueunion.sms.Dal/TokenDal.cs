﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.OracleClient;
using lyw.blueunion.sms.stores.Utilities;
namespace lyw.blueunion.sms.Dal
{
  public  class TokenDal
    {
      public bool validateAccount(string staffId, string staffSecret)
      {

          string sql = string.Format("select * from LYW_WEB_API_ACCOUNT where STAFFID='{0}'", staffId);
          DataTable dt = OracleHelper.GetTable(sql, null);
          if (dt.Rows.Count == 0)
              return false;
          string secret = dt.Rows[0]["STAFFSECRET"].ToString();
          if (secret.Equals(staffSecret))
              return true;
          else
              return false;

      }
    }
}
