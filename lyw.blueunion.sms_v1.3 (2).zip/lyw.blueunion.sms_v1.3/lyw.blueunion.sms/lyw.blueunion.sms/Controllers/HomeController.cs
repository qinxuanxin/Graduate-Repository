﻿using lyw.blueunion.sms.clientModels;
using lyw.blueunion.sms.clientUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace lyw.blueunion.sms.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            //业务办理进度
        //    模版CODE:SMS_89665068
//模版内容:您好，您申请的${type}业务办理进度状态有更新，请及时查看！
            //验证码
               //    模版CODE:SMS_129757561
//模版内容:您的验证码为:${code},该验证码5分钟内有效,请勿泄露于他人。
            string validatecode = new Random().Next(111111, 999999).ToString();
            string temppar="{'code':'" + validatecode + "'}";
        //    string temppar = "{'type':'视频'}";
          //  string code = "SMS_89665068";//我的业务进度
          //  string code = "SMS_130915976";//电子联盟
            string code = "SMS_129757561";//我的短信验证码
          //  string accesskeyid = "LTAIcI6HnskaEPcd";//电子联盟账号
           // string accesskeysecret = "8msoPHZT60r2RFkywOwU96wteISnFu";//电子联盟密码
          //  string signame = "蓝联盟众创空间";
             string accesskeyid = "LTAI2pVIR8OKNxPv";//我的
             string accesskeysecret = "v3aEoHynOoxkG2uVyArUfaJzCItrSj";//我的
              string signame = "乐意为";
            string jsonData =
          "{" +
              "\"Mobile\":\"18305180702\"," +
              "\"AccessKeyId\":\"" + accesskeyid + "\"," +
              "\"AccessKeySecret\":\"" + accesskeysecret + "\"," +
              "\"SignName\":\"" + signame + "\"," +
              "\"TemplateCode\":\"" + code + "\"," +
              "\"TemplateParam\":\"" + temppar + "\"," +
              "\"Validatecode\":\"" + validatecode + "\"" +
              //"\"TemplateParam\":\""++"\"" +
              //"\"{" +
              //    "\"code\":\"" + validatecode + "\"" +
              //"}\"" +
          "}";
     var smslong="http://egov.jinyuc.com/lyw.api/lywapi/sendsms/FlexGetValidateCode";
     var smslocal = "http://localhost:47368/lywapi/sendsms/FlexGetValidateCode";
     var smslocal1 = "http://localhost:47368/lywapi/values/get";
            //  var product2 = WebApiHelper.Post<ProductResultMsg>(AppSettingsConfig.AddProductApi, JsonConvert.SerializeObject(product), staffId);
     ValidateResultMsg ss = WebApiHelper.Post<ValidateResultMsg>(smslong, jsonData, "ElectronicUnion");
     ViewBag.statuscode = ss.StatusCode;
     ViewBag.info = ss.Info;
     ViewBag.validatecode = validatecode;
            return View();
        }

    }
}
