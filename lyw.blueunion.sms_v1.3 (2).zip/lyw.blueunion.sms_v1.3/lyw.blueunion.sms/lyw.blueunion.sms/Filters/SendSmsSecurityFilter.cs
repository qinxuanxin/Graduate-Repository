﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;

using System.IO;
using System.Collections.Specialized;
using System.Text;

using Newtonsoft.Json;
using System.Web.Http.Controllers;
using lyw.blueunion.sms.Models;
using lyw.blueunion.sms.Utilities;
using lyw.blueunion.sms.IEnum;
namespace lyw.blueunion.sms.Filters
{
    public class SendSmsSecurityFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            ResultValidateMsg validateMsg = null;
            ResultTokenMsg tokenMsg = null;
            var request = actionContext.Request;
            string method = request.Method.Method;
            string staffid = string.Empty, staffsecret = string.Empty, timestamp = string.Empty, nonce = string.Empty, signature = string.Empty;


            if (request.Headers.Contains("staffid"))
            {
                staffid = HttpUtility.UrlDecode(request.Headers.GetValues("staffid").FirstOrDefault());
            }
            if (request.Headers.Contains("staffsecret"))
            {
                staffsecret = HttpUtility.UrlDecode(request.Headers.GetValues("staffsecret").FirstOrDefault());
            }
            if (request.Headers.Contains("timestamp"))
            {
                timestamp = HttpUtility.UrlDecode(request.Headers.GetValues("timestamp").FirstOrDefault());
            }
            if (request.Headers.Contains("nonce"))
            {
                nonce = HttpUtility.UrlDecode(request.Headers.GetValues("nonce").FirstOrDefault());
            }

            if (request.Headers.Contains("signature"))
            {
                signature = HttpUtility.UrlDecode(request.Headers.GetValues("signature").FirstOrDefault());
            }

            //GetToken方法不需要进行签名验证
            if (actionContext.ActionDescriptor.ActionName == "GetToken")
            {

                if (string.IsNullOrEmpty(staffid) || (string.IsNullOrEmpty(timestamp) || string.IsNullOrEmpty(nonce)))
                {
                    tokenMsg = new ResultTokenMsg();
                    tokenMsg.StatusCode = (int)StatusCodeEnum.Error;
                    tokenMsg.Info = EnumExtension.GetDescription(StatusCodeEnum.Error);//StatusCodeEnum.ParameterError.GetEnumText()

                    actionContext.Response = HttpResponseExtension.toJson(JsonConvert.SerializeObject(tokenMsg));
                    base.OnActionExecuting(actionContext);
                    return;
                }

                else
                {
                    base.OnActionExecuting(actionContext);
                    return;
                }
            }


            //判断请求头是否包含以下参数
            if (string.IsNullOrEmpty(staffid) || (string.IsNullOrEmpty(timestamp) || string.IsNullOrEmpty(nonce) || string.IsNullOrEmpty(signature)))
            {
                validateMsg = new ResultValidateMsg();
                validateMsg.StatusCode = "isp.parameter_has_null";
                validateMsg.Info = "请求参数不全";//StatusCodeEnum.ParameterError.GetEnumText()
                validateMsg.BizId = "";
                validateMsg.ValidataCode = "";
                actionContext.Response = HttpResponseExtension.toJson(JsonConvert.SerializeObject(validateMsg));
                base.OnActionExecuting(actionContext);
                return;
            }

            //判断timespan是否有效
            double ts1 = 0;
            double ts2 = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds;
            bool timespanvalidate = double.TryParse(timestamp, out ts1);
            double ts = ts2 - ts1;
            bool falg = ts > int.Parse(WebSettingConfig.Time_effctive) * 1000;//大于5分钟
            if (falg || (!timespanvalidate))
            {
                validateMsg = new ResultValidateMsg();
                validateMsg.StatusCode = "isp.url_invalid";
                validateMsg.Info = "该URL已经失效";//StatusCodeEnum.ParameterError.GetEnumText()
                validateMsg.BizId = "";
                validateMsg.ValidataCode = "";
                actionContext.Response = HttpResponseExtension.toJson(JsonConvert.SerializeObject(validateMsg));
                base.OnActionExecuting(actionContext);
                return;
            }


            //判断token是否有效
            Token token = (Token)HttpRuntime.Cache.Get(staffid.ToString());
            string signtoken = string.Empty;
            if (HttpRuntime.Cache.Get(staffid.ToString()) == null)
            {
                validateMsg = new ResultValidateMsg();
                validateMsg.StatusCode = "isp.token_invalid";
                validateMsg.Info = "请求token失效";//StatusCodeEnum.ParameterError.GetEnumText()
                validateMsg.BizId = "";
                validateMsg.ValidataCode = "";
                actionContext.Response = HttpResponseExtension.toJson(JsonConvert.SerializeObject(validateMsg));
                base.OnActionExecuting(actionContext);
                return;
            }
            else
            {
                signtoken = token.SignToken.ToString();
            }

            //根据请求类型拼接参数
            NameValueCollection form = HttpContext.Current.Request.QueryString;
            string data = string.Empty;
            switch (method)
            {
                case "POST":
                    Stream stream = HttpContext.Current.Request.InputStream;
                    string responseJson = string.Empty;
                    StreamReader streamReader = new StreamReader(stream);
                    data = streamReader.ReadToEnd();
                    break;
                case "GET":
                    //第一步：取出所有get参数
                    IDictionary<string, string> parameters = new Dictionary<string, string>();
                    for (int f = 0; f < form.Count; f++)
                    {
                        string key = form.Keys[f];
                        parameters.Add(key, form[key]);
                    }

                    // 第二步：把字典按Key的字母顺序排序
                    IDictionary<string, string> sortedParams = new SortedDictionary<string, string>(parameters);
                    IEnumerator<KeyValuePair<string, string>> dem = sortedParams.GetEnumerator();

                    // 第三步：把所有参数名和参数值串在一起
                    StringBuilder query = new StringBuilder();
                    while (dem.MoveNext())
                    {
                        string key = dem.Current.Key;
                        string value = dem.Current.Value;
                        if (!string.IsNullOrEmpty(key))
                        {
                            query.Append(key).Append(value);
                        }
                    }
                    data = query.ToString();
                    break;
                default:
                    validateMsg = new ResultValidateMsg();
                    validateMsg.StatusCode = "isp.http_method_wrong";
                    validateMsg.Info = "http请求类型不合法";//StatusCodeEnum.ParameterError.GetEnumText()
                    validateMsg.BizId = "";
                    validateMsg.ValidataCode = "";
                    actionContext.Response = HttpResponseExtension.toJson(JsonConvert.SerializeObject(validateMsg));
                    base.OnActionExecuting(actionContext);
                    return;
            }

            bool result = SignExtension.Validate(timestamp, nonce, staffid, signtoken, signature);
            if (!result)
            {
                validateMsg = new ResultValidateMsg();
                validateMsg.StatusCode = "isp.http_request_wrong";
                validateMsg.Info = "HTTP请求不合法,请求参数可能被篡改";
                validateMsg.BizId = "";
                validateMsg.ValidataCode = "";
                actionContext.Response = HttpResponseExtension.toJson(JsonConvert.SerializeObject(validateMsg));
                base.OnActionExecuting(actionContext);
                return;
            }
            else
            {
                base.OnActionExecuting(actionContext);
            }
        }
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            base.OnActionExecuted(actionExecutedContext);
        }
    }
}