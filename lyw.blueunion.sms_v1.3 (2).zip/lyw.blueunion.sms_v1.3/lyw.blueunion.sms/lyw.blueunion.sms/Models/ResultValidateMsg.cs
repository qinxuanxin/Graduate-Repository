﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace lyw.blueunion.sms.Models
{
    /// <summary>
    /// 封装返回信息类
    /// </summary>
    public class ResultValidateMsg
    {
        /// <summary>
        /// 状态码
        /// </summary>
        public string StatusCode { get; set; }

        /// <summary>
        /// 状态码描述
        /// </summary>
        public string Info { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>
        public string ValidataCode { get; set; }

        /// <summary>
        /// 发送回执ID
        /// </summary>
        public object BizId { get; set; }
    }
}