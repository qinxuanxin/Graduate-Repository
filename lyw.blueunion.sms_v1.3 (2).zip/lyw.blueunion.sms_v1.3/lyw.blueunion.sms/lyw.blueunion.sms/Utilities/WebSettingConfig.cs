﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace lyw.blueunion.sms.Utilities
{
    /// <summary>
    /// 获取配置节点下的常量
    /// </summary>
    public class WebSettingConfig
    {
        /// <summary>
        /// 产品名字
        /// </summary>
        public static string Ali_Product
        {
            get
            {
                return AppSettingValue("Ali_product");
            }
        }
        /// <summary>
        /// 域名
        /// </summary>
        public static string Ali_Domain
        {
            get
            {
                return AppSettingValue("Ali_domain");
            }
        }
        /// <summary>
        /// 用户名
        /// </summary>
        public static string Ali_AccessKeyId
        {
            get
            {
                return AppSettingValue("Ali_accesskeyid");
            }
        }
        /// <summary>
        /// 密码
        /// </summary>
        public static string Ali_AccessKeySecret
        {
            get
            {
                return AppSettingValue("Ali_accesskeysecret");
            }
        }
        /// <summary>
        /// 短信模板id
        /// </summary>
        public static string Ali_TemplateID
        {
            get
            {
                return AppSettingValue("Ali_valcode_template");
            }
        }
        /// <summary>
        /// 签名名称
        /// </summary>
        public static string Ali_SignName
        {
            get
            {
                return AppSettingValue("Ali_signname");
            }
        }
        /// <summary>
        /// 有效时间5分钟
        /// </summary>
        public static string Time_effctive
        {
            get
            {
                return AppSettingValue("Time_effctive");
            }
        }
      
        /// <summary>
        /// 获取配置节点通用方法
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        private static string AppSettingValue(string key)
        {
            return ConfigurationManager.AppSettings[key];
        }
    }
}